-- Repeat vs One-Time Customers
SELECT 
    CASE 
        WHEN COUNT(DISTINCT o.order_id) = 1 THEN 'One-Time'
        ELSE 'Repeat'
    END AS customer_type,
    COUNT(DISTINCT o.customer_id) AS num_customers
FROM orders o
GROUP BY customer_type;
