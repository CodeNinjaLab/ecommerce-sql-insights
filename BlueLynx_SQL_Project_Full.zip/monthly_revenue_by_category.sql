-- Monthly Revenue by Product Category
SELECT 
    DATE_TRUNC('month', o.order_date) AS month,
    p.category,
    SUM(o.total_price) AS total_revenue
FROM orders o
JOIN products p ON o.product_id = p.product_id
GROUP BY month, p.category
ORDER BY month, total_revenue DESC;
