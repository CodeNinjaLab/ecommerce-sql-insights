# E-commerce Sales and Customer Insights using SQL

**Client:** BlueLynx Retail (Canada)  
**Role:** Freelance SQL Data Analyst  
**Duration:** August – September 2024

---

## 🧩 Project Overview

BlueLynx Retail, a mid-sized Canadian e-commerce company, hired me to analyze customer and sales performance using their SQL-based transaction database.  
The goal was to extract insights on revenue, customer value, and regional trends to support the sales and marketing teams.

---

## 📊 Key Business Questions Answered

- What are the monthly revenue trends by product category?
- Which cities generate the most sales?
- Who are our most valuable customers?
- How many customers are repeat vs. one-time buyers?

---

## 🛠 Tools & Stack

- SQL (PostgreSQL)
- Excel (for report exports)
- Notion (for stakeholder communication)

---

## 📁 Datasets Used

- `customers.csv`: Customer locations and join dates  
- `products.csv`: Product catalog with categories and prices  
- `orders.csv`: Sales transaction history

---

## 🔍 SQL Scripts Included

| Script | Description |
|--------|-------------|
| `monthly_revenue_by_category.sql` | Aggregates monthly sales by product category |
| `top_cities_by_revenue.sql` | Identifies top 10 cities by total revenue |
| `rfm_segmentation.sql` | Segments customers using Recency, Frequency, and Monetary metrics |
| `repeat_vs_onetime_customers.sql` | Compares counts of one-time vs. repeat customers |

---

## ✅ Outcomes

- Delivered 15+ SQL queries for key metrics
- Helped sales team prioritize top-performing cities and customers
- Provided customer retention insights via RFM segmentation

---

## 📂 How to Use

1. Load the CSVs into your SQL database
2. Run each `.sql` script in your SQL editor
3. Use the outputs to build dashboards or reports

---

## 🔐 Note

All data used is synthetic and was generated for demonstration purposes. No real customer or transaction data is included.
