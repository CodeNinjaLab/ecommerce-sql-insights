-- Top 10 Cities by Total Revenue
SELECT 
    c.city,
    SUM(o.total_price) AS total_revenue,
    COUNT(DISTINCT o.order_id) AS total_orders
FROM orders o
JOIN customers c ON o.customer_id = c.customer_id
GROUP BY c.city
ORDER BY total_revenue DESC
LIMIT 10;
