-- RFM Segmentation
WITH customer_metrics AS (
    SELECT 
        o.customer_id,
        MAX(o.order_date) AS last_order_date,
        COUNT(o.order_id) AS frequency,
        SUM(o.total_price) AS monetary
    FROM orders o
    GROUP BY o.customer_id
),
days_since_last_order AS (
    SELECT 
        customer_id,
        DATE_PART('day', CURRENT_DATE - last_order_date) AS recency,
        frequency,
        monetary
    FROM customer_metrics
)
SELECT 
    customer_id,
    recency,
    frequency,
    monetary,
    CASE 
        WHEN recency < 30 AND frequency >= 3 THEN 'Loyal'
        WHEN recency BETWEEN 30 AND 90 THEN 'Recent'
        WHEN frequency = 1 THEN 'One-time'
        ELSE 'At-Risk'
    END AS rfm_segment
FROM days_since_last_order
ORDER BY monetary DESC;
